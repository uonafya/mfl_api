# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('facilities', '0002_auto_20151116_0921'),
        ('facilities', '0002_auto_20151114_1147'),
    ]

    operations = [
    ]
